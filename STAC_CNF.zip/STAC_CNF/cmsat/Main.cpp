/***************************************************************************************[Solver.cc]
Copyright (c) 2003-2006, Niklas Een, Niklas Sorensson
Copyright (c) 2007-2009, Niklas Sorensson
Copyright (c) 2009-2012, Mate Soos

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT
OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
**************************************************************************************************/

/**
@mainpage CryptoMiniSat
@author Mate Soos, and collaborators

CryptoMiniSat is an award-winning SAT solver based on MiniSat. It brings a
number of benefits relative to MiniSat, among them XOR clauses, extensive
failed literal probing, and better random search.

The solver basically performs the following steps:

1) parse CNF file into clause database

2) run Conflict-Driven Clause-Learning DPLL on the clauses

3) regularly run simplification passes on the clause-set

4) display solution and if not used as a library, exit

Here is a picture of of the above process in more detail:

\image html "main_flowgraph.png"

*/

#include "cmsat/constants.h"
#include <time.h>
#include <iostream>
#include <fstream>
#include <cassert>
#include <math.h>

#include "cmsat/time_mem.h"
#include "cmsat/constants.h"
#include "cmsat/DimacsParser.h"

#if defined(__linux__)
#include <fpu_control.h>
#endif

#include "cmsat/Main.h"
#include <boost/math/distributions/normal.hpp>

unsigned int gen_random(unsigned int n) {
	return rand() % n;
}

// Wilson Score Interval
double conf_interval_lower(double p, unsigned int n, double z) {

	double item = z * z / n;

	double result = p + item / 2;
	
	result -= z * sqrt(p * (1 - p) / n + item / (4 * n));
	
	return (result / (1 + item));

}

double conf_interval_upper(double p, unsigned int n, double z) {

	double item = z * z / n;

	double result = p + item / 2;
	
	result += z * sqrt(p * (1 - p) / n + item / (4 * n));
	
	return (result / (1 + item));

}

bool check_sat(CMSat::Solver &s, unsigned int &times) {

	times++;

	if (s.solve() == CMSat::l_True) {
		return true;
	} else if (s.solve() == CMSat::l_False) {
		return false;
	} else {
		std::cout << "error: Sat solver says unknown." << std::endl;
		exit(0);
	}

}

void gen_hash_func(CMSat::Solver &s, std::vector<bool> a) {

	assert(a.size() == s.nVars() + 1);

	CMSat::vec<CMSat::Lit> lits;

	for (unsigned int i = 0; i < s.nVars(); i++) {
		if (a[i]) lits.push(CMSat::Lit(i, true));
	}
	
	s.addXorClause(lits, a.back());

}

std::vector<bool> gen_random_param(unsigned int size) {
	
	std::vector<bool> vec;
	
	for (unsigned int i = 0; i < size; i++) {
		if (gen_random(2) == 0) {
			vec.push_back(false);
		} else {
			vec.push_back(true);
		}
	}
	
	return vec;
	
}

void read_file(CMSat::Solver &s, std::string filename) {
	
	// open input file
    #ifdef DISABLE_ZLIB
        FILE *	in = fopen(filename.c_str(), "rb");
    #else
        gzFile	in = gzopen(filename.c_str(), "rb");
    #endif // DISABLE_ZLIB

    #pragma omp single
    if (in == NULL) {
        std::cout << "error: Could not open file '" << filename << "' for reading" << std::endl;
        exit(1);
    }

	// parse
	CMSat::DimacsParser parser(&s, false, false, false);
	parser.parse_DIMACS(in);

    #ifdef DISABLE_ZLIB
		fclose(in);
    #else
		gzclose(in);
    #endif // DISABLE_ZLIB
	
}


int main(int argc, char **argv) {

	srand((int)time(0));

	if (argc != 4) {
		std::cout << "USAGE: ./stac_cnf <epsilon> <delta> <input-file>" << std::endl;
		exit(1);
	}

	CMSat::SolverConf conf;
	CMSat::GaussConf gaussconfig;
	
	const double epsilon = atof(argv[1]);
	const double delta = atof(argv[2]);
	boost::math::normal dist(0.0, 1.0);
	const double z = boost::math::quantile(dist, 1.0 - delta / 2);
	std::cout << "Z_" << 1 - delta / 2 << " = " << z << std::endl;
	const std::string filename = argv[3];
	
	std::vector<unsigned int> C, L;
	unsigned int t = 0;
	unsigned int query_counter = 0;
	
	while (true) {
	
		CMSat::Solver solver(conf, gaussconfig);
		read_file(solver, filename);
			
		std::vector<std::vector<bool> > matA;
	
		t++;
		unsigned int depth = 0;

		//set start depth
		double avg = 0;
		for (unsigned int i = 0; i < L.size(); i++) avg += L[i];
		avg /= L.size();
		unsigned int offset = 5;
		
		//leap frogging
		//goto depth = (avg - offset) directly
		for (unsigned int i = 0; i < avg - offset; i++) {
			//generate & push hash function
			matA.push_back(gen_random_param(solver.nVars() + 1));
			gen_hash_func(solver, matA.back());
			depth++;
		}
		
		if (check_sat(solver, query_counter)) {
			//step forward
				
			//generate & push new hash function
			matA.push_back(gen_random_param(solver.nVars() + 1));
			gen_hash_func(solver, matA.back());
			depth++;
			
			std::cout << "Iteration: " << t << "\tDepth: " << depth << std::endl;

			//get depth
			while (check_sat(solver, query_counter)) {		
				//generate & push hash function
				matA.push_back(gen_random_param(solver.nVars() + 1));
				gen_hash_func(solver, matA.back());
				depth++;
				
				std::cout << "Iteration: " << t << "\tDepth: " << depth << std::endl;
			}
		} else {
			//step back
			while (depth > 0) {
				//init new sovler object
				CMSat::Solver solver_back(conf, gaussconfig);
				read_file(solver_back, filename);
				
				//roll back depth
				depth--;
				for (unsigned int i = 0; i < depth; i++) {
					gen_hash_func(solver_back, matA[i]);
				}
				
				if (check_sat(solver_back, query_counter)){
					//depth found
					depth++;
					break;
				}
			}
			
			if (depth == 0) {
				//unsat problem
				std::cout << "Problem is unsat, no solutions." << std::endl;
				exit(1);
			}
			
		}
		
		//record depth in L and C
		L.push_back(depth);
		
		if (C.size() < depth) C.resize(depth, 0);
		
		for (unsigned int i = 0; i < depth; i++) {
			C[i]++;
		}
		
		//std::cout << t << "\t" << depth << std::endl;
		
		//dynamically compute the confidence interval
		double d = 0;
		for (unsigned int i = 1; i < C.size(); i++) {
			if (abs(C[i] - (double)t / 2) <= abs(C[d] - (double)t / 2)) d = i;
			//std::cout << C[i] << ' ';
		}
		
		if (C[d] == t) continue;		
		double p = 1.0 - (double)C[d] / t;
		double med = log(p) / log(1.0 - pow(0.5, (double)d));
		double lower_inner = conf_interval_lower(p, t, z);
		double upper_inner = conf_interval_upper(p, t, z);
		double lower = log(upper_inner) / log(1.0 - pow(0.5, (double)d));
		double upper = log(lower_inner) / log(1.0 - pow(0.5, (double)d));
		//std::cout << std::endl << t << '\t' << d << '\t' << abs(C[d] - (double)t / 2) << '\t' << C[d] << '\t' << med << std::endl;
		//std::cout << lower << '\t' << lower_inner << '\t' << upper << '\t' << upper_inner << std::endl;
		if (upper < med * (1 + epsilon) && lower > med / (1 + epsilon)) {
		
			for (unsigned int i = 0; i < C.size(); i++) {
				//double r = log(1.0 - (double)C[i] / t) / log(1.0 - pow(0.5, (double)i));
				//std::cout << i << "\t" << C[i] << "\t" <<  r << std::endl;
			}
			
			std::cout << "results: " << med << std::endl << t << '\t' << d << '\t' << C[d] << std::endl;
			std::cout << "bounds: [" << lower << ", " << upper << "]\t[" << lower_inner << ", " << upper_inner << "]\n";
			std::cout << "#query: " << query_counter << std::endl;
			std::ofstream outfile("results.txt", std::ios::app);
			outfile << t << ' ' << med << ' ' << query_counter << std::endl;
			outfile.close();
			break;
		}
				
	}

	return 0;

}



