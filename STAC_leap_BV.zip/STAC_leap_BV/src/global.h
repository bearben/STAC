#include <iostream>
#include <fstream>
#include <cassert>
#include <vector>
#include <set>
#include <ctime>
#include <math.h>
#include <z3++.h>
#include <stdlib.h>

#ifndef GLOBAL_HEADER
#define GLOBAL_HEADER

#endif
