#include <global.h>

z3::context ctx;
std::vector<z3::sort>		sorts;
std::vector<z3::func_decl>	funs;
std::vector<z3::expr>		todo;
std::vector<z3::expr>		vars;
std::set<unsigned>			seen_ids;

unsigned int query_counter;

unsigned int gen_random(unsigned int n) {
	return rand() % n;
}

bool contains_id(unsigned id) {
	return seen_ids.find(id) != seen_ids.end();
}

void collect_sort(z3::sort s) {
	unsigned id = Z3_get_sort_id(ctx, s);
	if (s.sort_kind() == Z3_UNINTERPRETED_SORT && contains_id(id)) {
		seen_ids.insert(id);
		sorts.push_back(s);
	}
}

void collect_fun(z3::func_decl f) {
	unsigned id = Z3_get_func_decl_id(ctx, f);
	if (contains_id(id)) {
		return;
	}
	seen_ids.insert(id);
	if (f.decl_kind() == Z3_OP_UNINTERPRETED) {
		funs.push_back(f);
	}
	for (unsigned i = 0; i < f.arity(); ++i) {
		collect_sort(f.domain(i));
    }
	collect_sort(f.range());
}

void collect_decls(z3::expr e) {
	todo.push_back(e);
	while (!todo.empty()) {
		z3::expr e = todo.back();
		todo.pop_back();
		unsigned id = Z3_get_ast_id(ctx, e);
		if (contains_id(id)) {
			continue;
		}
		seen_ids.insert(id);
		if (e.is_app()) {
			collect_fun(e.decl());
			unsigned sz = e.num_args();
			for (unsigned i = 0; i < sz; ++i) {
				todo.push_back(e.arg(i));
			}
		} else if (e.is_quantifier()) {
			unsigned nb = Z3_get_quantifier_num_bound(e.ctx(), e);
			for (unsigned i = 0; i < nb; ++i) {
				z3::sort srt(ctx, Z3_get_quantifier_bound_sort(e.ctx(), e, i));
				collect_sort(srt);
			}
			todo.push_back(e.body());
		}
		else if (e.is_var()) {
			collect_sort(e.get_sort());
		}
	}
}


void extract_vars(z3::solver s) {

	for (unsigned int i = 0; i < funs.size(); i++) {
	
		z3::func_decl f = funs[i];
		z3::sort fsort = f.range();
		
		if (fsort.is_bv()) {
			//bit-vector - create new vars to represent each bit
			for (unsigned int j = 0; j < fsort.bv_size(); j++) {
				//create name for new var
				char name[255];
				sprintf(name, "%s_%d", f.name().str().c_str(), j);
				
				z3::expr new_f = ctx.bv_const(name, 1);
				vars.push_back(new_f);
				
				s.add(new_f == to_expr(ctx, Z3_mk_extract(ctx, j, j, f())));
			}
		}// else {
			//boolean - reuse
			//vars.push_back(f());
		//}
	
	}

}

z3::expr gen_hash_func() {

	bool b = gen_random(2);
	//std::cout << b << ' ';
	z3::expr e = ctx.bv_val(b, 1);
	
	for (unsigned int i = 0; i < vars.size(); i++) {
		b = gen_random(2);
		//std::cout << b << vars[i].decl().name() << ' ';
		e = e ^ (ctx.bv_val(b, 1) & vars[i]);
	}
	
	b = gen_random(2);
	//std::cout << b << std::endl;
	e = e == ctx.bv_val(gen_random(2), 1);

	return e;

}

z3::expr negate_model(z3::model m) {

	z3::expr e = (m[0]() != m.get_const_interp(m[0]));

	for (unsigned int i = 1; i < m.size(); i++) {
		z3::func_decl f = m[i];
		e = e || (f() != m.get_const_interp(f));
	}
	
	return e;

}


bool check_sat_z3(z3::solver s) {

	clock_t start, end;
	start = clock();
	z3::check_result result = s.check();
	end = clock();
	std::cout << "use time: " << (double)(end - start) / CLOCKS_PER_SEC << " s" << std::endl;
	
	if (result == z3::sat) {
		//sat
		std::cout << "sat" << std::endl;
		return true;
	} else if (result == z3::unsat) {
		//unsat
		std::cout << "unsat" << std::endl;
		return false;
	} else {
		//unknown
		std::cout << "unknown" << std::endl;
		exit(0);
	}
	
}

bool check_sat_boolector(z3::solver s) {

	query_counter++;

	std::ofstream outfile("temp.smt2");
	outfile << s.to_smt2();
	outfile.close();
	
	//std::string str = "time ./boolector --lingeling temp.smt2 > temp.txt";
	std::string str = "./boolector --lingeling temp.smt2 > temp.txt";
	system(str.c_str());

	std::ifstream infile;
	infile.open("temp.txt");	
	getline(infile, str);
	infile.close();

	if (str.substr(0, 3) == "sat"){
		//sat
		//std::cout << "sat" << std::endl;
		return true;
	} else if (str.substr(0, 5) == "unsat") {
		//unsat
		//std::cout << "unsat" << std::endl;
		return false;
	} else {
		//unknown
		std::cout << "unknown" << std::endl;
		exit(0);
	}

}


void print_model(z3::model m) {

	std::cout << "Print model:"  << std::endl;

	for (unsigned int i = 0; i < m.size(); i++) {
		z3::func_decl f = m[i];
		//this problem contains only constants
		//assert(f.arity() == 0);
		std::cout << f.name() << " = " << m.get_const_interp(f) << std::endl;
	}

}


double conf_interval_lower(double p, unsigned int n, double z) {

	double item = z * z / n;

	double result = p + item / 2;
	
	result -= z * sqrt(p * (1 - p) / n + item / (4 * n));
	
	return (result / (1 + item));

}

double conf_interval_upper(double p, unsigned int n, double z) {

	double item = z * z / n;

	double result = p + item / 2;
	
	result += z * sqrt(p * (1 - p) / n + item / (4 * n));
	
	return (result / (1 + item));

}

int main(int argc, char **argv) {

	srand((int)time(0));
	
	if (argc != 2) {
		std::cout << "USAGE: ./stac_bv <input-file>\n";
		exit(1);
	}
	
	query_counter = 0;

	//read & create problem	
	Z3_ast a = Z3_parse_smtlib2_file(ctx, argv[1], 0, 0, 0, 0, 0, 0);
	z3::expr e = to_expr(ctx, a);
	z3::solver s(ctx);
	s.add(e);


	//collect declared consts
	collect_decls(e);
	for (unsigned int i = 0; i < funs.size(); i++) {
		std::cout << funs[i].name() << ' ' << funs[i].range() << std::endl;
		//this problem contains only bvs and bools
		z3::sort fsort = funs[i].range();
		assert(fsort.sort_kind() == Z3_BV_SORT || fsort.sort_kind() == Z3_BOOL_SORT);
	}

	//extract variables
	extract_vars(s);
	std::cout << "Total number of Boolean variables: " << vars.size() << std::endl;


	std::vector<unsigned int> C, L;
	unsigned int t = 0;
	while (true) {
		t++;
		unsigned int depth = 0;

		//set start depth
		double avg = 0;
		for (unsigned int i = 0; i < L.size(); i++) avg += L[i];
		avg /= L.size();
		unsigned int offset = 5;
		
		//leap frogging
		//goto depth = (avg - offset) directly
		for (unsigned int i = 0; i < avg - offset; i++) {
			//generate & push hash function
			s.push();
			s.add(gen_hash_func());
			depth++;
		}
		
		while (depth > 0 && !check_sat_boolector(s)) {
			for (unsigned int i = 0; i < offset && depth > 0; i++){
				s.pop();
				depth--;
			}
		}
		
		std::cout << depth << '\t';

		//generate & push hash function
		s.push();
		s.add(gen_hash_func());
		depth++;

		//get depth
		while (check_sat_boolector(s)) {
			//print_model(s.get_model());
		
			//generate & push hash function
			s.push();
			s.add(gen_hash_func());
			depth++;
			//std::cout << depth << std::endl;
		}
		
		//record depth in L and C
		L.push_back(depth);
		
		if (C.size() < depth) C.resize(depth, 0);
		
		for (unsigned int i = 0; i < depth; i++) {
			C[i]++;
			s.pop();
		}
		
		std::cout << t << "\t" << depth << std::endl;
		
		//dynamically compute the confidence interval
		double d = 0;
		for (unsigned int i = 1; i < C.size(); i++) {
			if (abs(C[i] - (double)t / 2) <= abs(C[d] - (double)t / 2)) d = i;
		}
		
		if (C[d] == t) continue;		
		double p = 1.0 - (double)C[d] / t;
		double med = log(p) / log(1.0 - pow(0.5, (double)d));
		double lower_inner = conf_interval_lower(p, t, 1.28);
		double upper_inner = conf_interval_upper(p, t, 1.28);
		double lower = log(upper_inner) / log(1.0 - pow(0.5, (double)d));
		double upper = log(lower_inner) / log(1.0 - pow(0.5, (double)d));
		if (upper < med * 1.8 && lower > med / 1.8) {
		
			for (unsigned int i = 0; i < C.size(); i++) {
				double r = log(1.0 - (double)C[i] / t) / log(1.0 - pow(0.5, (double)i));
				std::cout << i << "\t" << C[i] << "\t" <<  r << std::endl;
			}
			
			std::cout << "results: " << med << std::endl << t << '\t' << d << '\t' << C[d] << std::endl;
			std::cout << "bounds: [" << lower << ", " << upper << "]\t[" << lower_inner << ", " << upper_inner << "]\n";
			std::cout << "#query: " << query_counter << std::endl;
			std::ofstream outfile("results.txt", std::ios::app);
			outfile << t << ' ' << med << ' ' << query_counter << std::endl;
			outfile.close();
			break;
		}
		
	}
	
/*
	if ((uc - T / 2) <= (T / 2 - lc)) {
		std::cout << ur << std::endl;
		outfile << ur << std::endl;
	} else {
		std::cout << lr << std::endl;
		outfile << lr << std::endl;
	}
*/

	return 0;

}
